import javax.swing.*;


public JPanel getGamePanel() {
        return null; // Inutilisé maintenant
    }

    public void setGamePanel(JPanel gamePanel) {
        // Ne rien faire, plus nécessaire
    }
